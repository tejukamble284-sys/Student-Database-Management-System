"""Command-line Student Database Management System using Python and MySQL."""

import os
import sys
import mysql.connector
from mysql.connector import Error, IntegrityError


def connect_db():
    """Connect using environment variables; never commit real credentials."""
    return mysql.connector.connect(
        host=os.getenv("DB_HOST", "localhost"),
        user=os.getenv("DB_USER", "root"),
        password=os.getenv("DB_PASSWORD", ""),
        database=os.getenv("DB_NAME", "student_db"),
    )


def read_int(prompt, minimum=1, maximum=8):
    while True:
        raw = input(prompt).strip()
        try:
            value = int(raw)
            if minimum <= value <= maximum:
                return value
            print(f"Enter a number from {minimum} to {maximum}.")
        except ValueError:
            print("Please enter a valid whole number.")


def add_student(conn):
    name = input("Full name: ").strip()
    email = input("Email: ").strip()
    course = input("Course: ").strip()
    year = read_int("Year of study (1-8): ")

    if not name or not email or not course:
        print("Name, email, and course cannot be empty.")
        return

    sql = """
        INSERT INTO students (full_name, email, course, year_of_study)
        VALUES (%s, %s, %s, %s)
    """
    try:
        with conn.cursor() as cursor:
            cursor.execute(sql, (name, email, course, year))
        conn.commit()
        print("Student added successfully.")
    except IntegrityError:
        conn.rollback()
        print("That email already exists. Please use a different email.")


def list_students(conn):
    with conn.cursor(dictionary=True) as cursor:
        cursor.execute(
            """SELECT student_id, full_name, email, course, year_of_study, created_at
               FROM students ORDER BY student_id"""
        )
        rows = cursor.fetchall()

    if not rows:
        print("No student records found.")
        return

    for row in rows:
        print(
            f"ID: {row['student_id']} | {row['full_name']} | {row['email']} | "
            f"{row['course']} | Year {row['year_of_study']}"
        )


def search_student(conn):
    student_id = read_int("Student ID: ", minimum=1, maximum=2_147_483_647)
    with conn.cursor(dictionary=True) as cursor:
        cursor.execute(
            "SELECT student_id, full_name, email, course, year_of_study "
            "FROM students WHERE student_id = %s",
            (student_id,),
        )
        row = cursor.fetchone()

    if row:
        print(row)
    else:
        print("Student not found.")


def update_student(conn):
    student_id = read_int("Student ID to update: ", minimum=1, maximum=2_147_483_647)
    name = input("New full name: ").strip()
    email = input("New email: ").strip()
    course = input("New course: ").strip()
    year = read_int("New year of study (1-8): ")

    if not name or not email or not course:
        print("Name, email, and course cannot be empty.")
        return

    try:
        with conn.cursor() as cursor:
            cursor.execute(
                """UPDATE students
                   SET full_name = %s, email = %s, course = %s, year_of_study = %s
                   WHERE student_id = %s""",
                (name, email, course, year, student_id),
            )
            changed = cursor.rowcount
        conn.commit()
        print("Student updated." if changed else "No matching student found (or no changes made).")
    except IntegrityError:
        conn.rollback()
        print("That email is already used by another student.")


def delete_student(conn):
    student_id = read_int("Student ID to delete: ", minimum=1, maximum=2_147_483_647)
    confirm = input(f"Delete student ID {student_id}? Type YES to confirm: ").strip()
    if confirm != "YES":
        print("Delete cancelled.")
        return

    with conn.cursor() as cursor:
        cursor.execute("DELETE FROM students WHERE student_id = %s", (student_id,))
        deleted = cursor.rowcount
    conn.commit()
    print("Student deleted." if deleted else "Student not found.")


def main():
    try:
        conn = connect_db()
    except Error as exc:
        print("Could not connect to MySQL.")
        print("Check that MySQL is running and DB_HOST, DB_USER, DB_PASSWORD, DB_NAME are correct.")
        print(f"Details: {exc}")
        return 1

    actions = {
        "1": ("Add student", add_student),
        "2": ("List students", list_students),
        "3": ("Search student by ID", search_student),
        "4": ("Update student", update_student),
        "5": ("Delete student", delete_student),
    }

    try:
        while True:
            print("\n=== Student Database Management System ===")
            for key, (label, _) in actions.items():
                print(f"{key}. {label}")
            print("0. Exit")
            choice = input("Choose an option: ").strip()

            if choice == "0":
                print("Goodbye!")
                break
            if choice not in actions:
                print("Please choose a valid menu option.")
                continue

            try:
                actions[choice][1](conn)
            except Error as exc:
                conn.rollback()
                print(f"Database operation failed: {exc}")
    finally:
        conn.close()

    return 0


if __name__ == "__main__":
    sys.exit(main())
