# Student Database Management System

A beginner-friendly database project built with Python and MySQL. It demonstrates relational database design, CRUD operations, input validation, and parameterized SQL queries.

## Features
- Add a student
- View all students
- Search by student ID
- Update student details
- Delete a student
- MySQL table with primary key and unique email
- Parameterized queries to reduce SQL injection risk

## Tech Stack
- Python 3
- MySQL 8+
- `mysql-connector-python`

## Database Schema
Database: `student_db`

Table: `students`
- `student_id` — integer primary key, auto-increment
- `full_name` — required text
- `email` — required, unique
- `course` — required text
- `year_of_study` — integer

## Setup

1. Install Python 3 and MySQL.
2. Create a virtual environment (optional).
3. Install the dependency:

```bash
pip install -r requirements.txt
```

4. Create the database and table by running the SQL file in MySQL:

```bash
mysql -u root -p < schema.sql
```

5. Set your MySQL connection values as environment variables, or edit the defaults in `app.py` for your local machine:

```bash
# Windows PowerShell
$env:DB_HOST="localhost"
$env:DB_USER="root"
$env:DB_PASSWORD="your_password"
$env:DB_NAME="student_db"
python app.py
```

```bash
# macOS/Linux
export DB_HOST="localhost"
export DB_USER="root"
export DB_PASSWORD="your_password"
export DB_NAME="student_db"
python app.py
```

## Example workflow
Choose menu option 1 to add a student, option 2 to list students, and options 3–5 to search, update, or delete a record.

## Learning Outcomes
- Relational schema design and constraints
- CRUD operations using SQL
- Connecting Python applications to MySQL
- Using parameterized queries
- Handling database errors

## Possible Improvements
- Add automated tests
- Add pagination and sorting
- Add a web interface with Flask
- Add role-based authentication

## Author
Add your name here before publishing.
