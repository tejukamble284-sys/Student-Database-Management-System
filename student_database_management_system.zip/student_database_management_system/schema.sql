CREATE DATABASE IF NOT EXISTS student_db;
USE student_db;

CREATE TABLE IF NOT EXISTS students (
    student_id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    course VARCHAR(100) NOT NULL,
    year_of_study TINYINT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_year_of_study CHECK (year_of_study BETWEEN 1 AND 8)
);

-- Optional sample records for testing:
INSERT IGNORE INTO students (full_name, email, course, year_of_study)
VALUES
    ('Aarav Patil', 'aarav.example@example.com', 'Computer Science', 3),
    ('Meera Shah', 'meera.example@example.com', 'Information Technology', 2);
